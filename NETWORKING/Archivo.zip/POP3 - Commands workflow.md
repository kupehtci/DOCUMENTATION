#NETWORKING 




### Basic usage

```bash
+OK Dovecot (Debian) ready.
USER daniel     
+OK
PASS pass123
+OK Logged in.
list 
+OK 2 messages:
1 318
2 328
```

This means we have two messages in queue. 


