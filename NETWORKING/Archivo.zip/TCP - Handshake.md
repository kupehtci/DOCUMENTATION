### TCP 

TCP opens a  full-duplex communication channel, that can sent data in both directions at the same time. 