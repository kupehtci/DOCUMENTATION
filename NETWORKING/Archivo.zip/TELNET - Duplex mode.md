#NETWORKING 


### TELNET duplex mode 

For maximum compatibility, the NVT assumes <span style="color:cyan;">half-duplex operations</span>. 

`HALF-DUPLEX OPERATIONS`

This type of operations allows only one device to communicate at a time. 

`FULL-DUPLEX OPERATIONS`

Can also operate in full duplex mode, meaning that communication is sent from both directions since TCP sessions can handle this type of comunication. 
