#NETWORKING 

## IMAP

<span style="color:orange;">IMAP or Internet Message Access Protocol</span> is a Networking protocol that allows to retrieve mails from a server, but leaving it in the server and implements synchronization for accessing by multiple computers. 

Emails are view remotely and not being deleted once they are retrieved. Can also be seen offline if they are cached. 


