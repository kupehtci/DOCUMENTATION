#NETWORKING 
### DNAME Records

DNAME records or name delegate record generates an alias for an entire tree of names, despite CNAME [[DNS - CNAME]] that only points to one domain name