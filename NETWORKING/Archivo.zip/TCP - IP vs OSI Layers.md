### Equivalency 

The OSI and TCP-IP layers are equivalent in this diagram: 

Keeping in mind that Application, Presentation and Session Layers in OSI are equivalent to Application Layer in TCP/IP and Data Link and Physical Layer (OSI) is the network access layer. 

This is meant to simplify the OSI model using the other structure. 

![[OSI-vs-TCP-vs-Hybrid-2.webp|400]]

