#NETWORKING


The TCP-IP layers: 

* `Application Layer`: 
* `Transport Layer`: 
* `Network Layer`: 
* `Network Access Layer`: 

The 

![[OSI-vs-TCP-vs-Hybrid-2.webp|400]]

