#NETWORKING 

The <span style ="color:#ababf5;">Open Systems Interconnection</span> (OSI) describes seven layers used to communicate over the network. 

7. `Application Layer`: Human computer interaction layer. 
6. `Presentation Layer`: 
5. `Session Layer`: 
4. `Transport Layer`: 
3. `Network Layer`: 
2. `Data Link Layer`: 
1. `Physical Layer`: 
